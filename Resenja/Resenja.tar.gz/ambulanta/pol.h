#ifndef POL_H_INCLUDED
#define POL_H_INCLUDED

enum Pol {MUSKI=0, ZENSKI};

#endif // POL_H_INCLUDED
